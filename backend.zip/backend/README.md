## OnlineStore Backend Service

### Разработка
- После создания чистого virtualenv (через конду) нужно в него поставить следующие пакеты и poetry:
  ```shell
  pip install --upgrade pip==23.3.2 setuptools==69.5.1 wheel==0.43.0 virtualenv==20.26.1
  ```
  ```shell
  pip install --upgrade poetry==1.8.3
  ```
  Потом отключаем создание virtualenv через poetry (потому что мы используем конду):
  ```shell
  poetry config virtualenvs.create false
  ```
  А потом по очереди ставим текущий пакет:
  ```shell
  poetry install
  ```
  Устанавливаем все зависимости в одну среду.

- Для автоматического запуска ruff, isort, nbstripout и docformatter необходимо инициализировать pre-commit после клонирования репозитория:
  ```shell
  pre-commit install
  ```
  Теперь перед каждым коммитом будет запускаться проверка кода.

- Команды для запуска форматтеров:
  ```shell
  ruff check --fix .
  ruff format .
  isort .
  docformatter --in-place .
  ```

- <b>ВАЖНО!</b> - Настройки перменных окружения
  ```shell
  export BACKEND_CONFIG_PATH="<полный путь до файла config.yaml (пример в config.exmaple.yaml)>"
  export PYTHONPATH="<полный путь до директории /online-store/backend>:$PYTHONPATH"
  ``` 

## Можно запускаться как будет удобно :)
  
- Добавить новый пакет в зависимости
  
  1. В pyproject.toml добавляем руками пакет с нужной версией.
  2. Делаем `poetry lock --no-update` для фиксации всех зависимостей в poetry.lock.
  3. Делаем `poetry install` для установки новых зависимостей.