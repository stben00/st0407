from django.conf import settings
from storages.backends.s3boto3 import S3Boto3Storage


class MediaStorage(S3Boto3Storage):
    location = settings.AWS_LOCATION
    default_acl = "public-read"
    file_overwrite = False
    custom_domain = settings.AWS_S3_CUSTOM_DOMAIN
    querystring_auth = False
