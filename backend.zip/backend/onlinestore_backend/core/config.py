import os

import yaml
from pydantic_settings import BaseSettings


class DBConfig(BaseSettings):
    engine: str | None = None
    host: str | None = None
    port: int | None = None
    name: str
    user: str | None = None
    password: str | None = None


class AWSS3Config(BaseSettings):
    access_key_id: str
    secret_access_key: str
    bucket_name: str
    region_name: str


class TelegramConfig(BaseSettings):
    token: str
    chat_id: int


class Config(BaseSettings):
    debug: bool = False
    secret_key: str
    csrf_trusted_origins: list[str]

    db: DBConfig
    aws_s3: AWSS3Config = None
    telegram: TelegramConfig = None


def get_config() -> Config:
    if "BACKEND_CONFIG_PATH" in os.environ:
        with open(os.environ["BACKEND_CONFIG_PATH"]) as f:
            config_dict = yaml.safe_load(f)
        return Config(**config_dict)
    raise Exception("There is no 'BACKEND_CONFIG_PATH' env var")


config = get_config()
