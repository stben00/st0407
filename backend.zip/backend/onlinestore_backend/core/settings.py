from pathlib import Path

from onlinestore_backend.core.config import config

BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = config.secret_key
DEBUG = config.debug

ALLOWED_HOSTS = ["*"]

CSRF_TRUSTED_ORIGINS = config.csrf_trusted_origins

INSTALLED_APPS = [
    # UI
    "jazzmin",
    # Default
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    # DEPS
    "ninja",
    # LOCAL APPS
    "onlinestore_backend.apps.products",
]

if not DEBUG:
    INSTALLED_APPS += ["storages"]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "whitenoise.middleware.WhiteNoiseMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "corsheaders.middleware.CorsMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "onlinestore_backend.core.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [BASE_DIR / "templates"],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "onlinestore_backend.core.wsgi.application"

DATABASES = {
    "default": {
        "ENGINE": config.db.engine,
        "NAME": config.db.name,
        "USER": config.db.user,
        "PASSWORD": config.db.password,
        "HOST": config.db.host,
        "PORT": config.db.port,
    }
}

AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]

LANGUAGE_CODE = "ru-RU"

TIME_ZONE = "Asia/Almaty"

USE_I18N = True

USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.2/howto/static-files/

STATIC_ROOT = BASE_DIR / "static"
STATIC_URL = "static/"

# S3 - Media

if DEBUG:
    MEDIA_URL = "/media/"
    MEDIA_ROOT = BASE_DIR / "media"

    STORAGES = {
        "default": {
            "BACKEND": "django.core.files.storage.FileSystemStorage",
            "OPTIONS": {
                "location": MEDIA_ROOT,
            },
        },
        "staticfiles": {
            "BACKEND": "whitenoise.storage.CompressedManifestStaticFilesStorage",
        },
    }
else:
    AWS_BUCKET_NAME = config.aws_s3.bucket_name
    AWS_REGION = config.aws_s3.region_name
    AWS_MEDIA_LOCATION = "media"

    MEDIA_URL = f"https://{AWS_BUCKET_NAME}.s3.amazonaws.com/{AWS_MEDIA_LOCATION}/"

    STORAGES = {
        "default": {
            "BACKEND": "storages.backends.s3boto3.S3Boto3Storage",
            "OPTIONS": {
                "access_key": config.aws_s3.access_key_id,
                "secret_key": config.aws_s3.secret_access_key,
                "bucket_name": AWS_BUCKET_NAME,
                "region_name": AWS_REGION,
                "location": AWS_MEDIA_LOCATION,
                "custom_domain": f"{AWS_BUCKET_NAME}.s3.amazonaws.com",
                "file_overwrite": False,
                "querystring_auth": False,
                "object_parameters": {
                    "CacheControl": "max-age=86400",
                },
            },
        },
        "staticfiles": {
            "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
        },
    }

DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# CORS
CORS_ALLOW_ALL_ORIGINS = True
CORS_ALLOW_CREDENTIALS = True
