from django.conf.urls.static import static
from django.contrib import admin
from django.urls import path
from ninja import NinjaAPI

from onlinestore_backend.core import settings
from onlinestore_backend.apps.public_api import public_router

# Публичный API
public_api = NinjaAPI(
    title="Online Store Public API",
    version="1.0",
    description="Public API",
    urls_namespace="public",
    docs_url="/docs",
)

public_api.add_router("/", public_router)

urlpatterns = [
    path('admin/', admin.site.urls),
    path("api/public/v1/", public_api.urls),
]
urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


admin.site.site_header = "Управление магазином"
admin.site.site_title = "Админка OnlineStore"
admin.site.index_title = "Добро пожаловать в админку"
