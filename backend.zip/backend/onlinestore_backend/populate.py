import os
import django
import random
import requests
from io import BytesIO
from django.core.files import File

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "onlinestore_backend.core.settings")
django.setup()

from onlinestore_backend.apps.products.models import Category, Product, ProductImage

# --- Создаём категории ---
category_titles = [
    "Электроника", "Одежда", "Книги", "Игрушки", "Дом", "Спорт", "Авто", "Красота"
]

categories = []

for title in category_titles:
    category, created = Category.objects.get_or_create(title=title)
    # скачиваем случайную картинку для категории
    url = f"https://picsum.photos/200/200?random={random.randint(1,1000)}"
    response = requests.get(url)
    if response.status_code == 200:
        category.image.save(f"{title}.jpg", File(BytesIO(response.content)), save=True)
    categories.append(category)

print(f"Создано категорий: {len(categories)}")

# --- Создаём товары ---
product_titles = [
    "Классный товар", "Лучший продукт", "Новинка", "Хит продаж", "Супер качество"
]

for category in categories:
    for i in range(5):  # по 5 товаров на категорию
        title = f"{random.choice(product_titles)} {i+1}"
        price = round(random.uniform(10, 500), 2)
        description = f"Описание для {title}"
        product = Product.objects.create(
            title=title,
            description=description,
            price=price,
            category=category,
            is_popular=random.choice([True, False])
        )
        # добавляем 1-3 картинки для товара
        for j in range(random.randint(1, 3)):
            url = f"https://picsum.photos/400/300?random={random.randint(1,1000)}"
            response = requests.get(url)
            if response.status_code == 200:
                ProductImage.objects.create(
                    product=product,
                    image=File(BytesIO(response.content), name=f"{title}_{j}.jpg")
                )

print("Товары созданы ✅")
