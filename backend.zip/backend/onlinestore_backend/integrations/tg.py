from ninja import Schema
from telegram import Bot

from core.config import config

bot = Bot(token=config.telegram.token)


async def send_order_notification(order: Schema):
    message = f"📦 Новый заказ!\n\n"
    message += f"Имя: {order.name}\n"
    message += f"Телефон: {order.phone}\n\n"
    message += "Товары:\n"

    for item in order.products:
        message += f"- {item.title} x {item.quantity} = {item.price * item.quantity:.2f} ₸\n"

    message += f"\n💰 Итого: {order.total_price:.2f} ₸"

    await bot.send_message(chat_id=config.telegram.chat_id, text=message)
