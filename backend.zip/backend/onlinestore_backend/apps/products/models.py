from django.db import models


class Category(models.Model):
    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"

    title = models.CharField(max_length=100)
    image = models.ImageField(upload_to="category_images/", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    modified_at = models.DateTimeField(auto_now=True, null=True)

    def __str__(self) -> str:
        return self.title


class Product(models.Model):
    class Meta:
        verbose_name = "Товар"
        verbose_name_plural = "Товары"

    category = models.ForeignKey(verbose_name="Категория", to=Category, on_delete=models.CASCADE, null=True)

    title = models.CharField(verbose_name="Название товара", max_length=256)
    description = models.TextField(verbose_name="Описание")
    price = models.FloatField(verbose_name="Цена")
    is_popular = models.BooleanField(verbose_name="Популярный товар", default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self) -> str:
        return self.title


class ProductImage(models.Model):
    class Meta:
        verbose_name = "Фотография"
        verbose_name_plural = "Фотографии"

    product = models.ForeignKey(
        Product,
        related_name="images",
        on_delete=models.CASCADE
    )
    image = models.ImageField(upload_to="product_images/")

    def __str__(self) -> str:
        return f"Image for {self.product.title}"


class Banner(models.Model):

    class Meta:
        verbose_name = "Баннер"
        verbose_name_plural = "Баннеры"

    image = models.ImageField(upload_to="banner_images/")
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self) -> str:
        return self.image.url


class Order(models.Model):

    class Meta:
        verbose_name = "Заказ"
        verbose_name_plural = "Заказы"

    name = models.CharField(max_length=100)
    phone = models.CharField(max_length=100)
    products = models.ManyToManyField(Product, related_name="orders")
    total_price = models.FloatField()

    created_at = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self) -> str:
        return f"{self.name} {self.phone} {self.total_price}"
