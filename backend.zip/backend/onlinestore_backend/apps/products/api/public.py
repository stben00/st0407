import asyncio
from datetime import datetime
from django.http import HttpRequest
from ninja import Router, Schema, Query
from typing import List

from integrations.tg import send_order_notification
from onlinestore_backend.apps.products.models import Product, Category, Banner, Order

router = Router(tags=["Products"])


class ProductImageOutSchema(Schema):
    url: str


class ProductOutSchema(Schema):
    id: int
    title: str
    description: str
    price: float
    images: List[ProductImageOutSchema]
    created_at: datetime


class CategoryOutSchema(Schema):
    id: int
    title: str
    created_at: datetime


class BannerOutSchema(Schema):
    id: int
    image: str
    created_at: datetime


class ProductInSchema(Schema):
    id: int
    title: str
    price: float
    quantity: int


class OrderInSchema(Schema):
    name: str
    phone: str
    products: List[ProductInSchema]
    total_price: float


@router.get(
    path="/categories/",
    description="Categories List",
    response={200: List[CategoryOutSchema]},
)
def list_categories(request: HttpRequest):
    data = Category.objects.all().order_by("created_at")
    return 200, data


@router.get(
    path="/",
    description="Products List",
    response={200: List[ProductOutSchema]},
)
def list_products(
        request: HttpRequest,
        category: int = Query(None),
        is_popular: int = Query(None),
):
    filters = {}
    if category:
        filters["category_id"] = category

    if is_popular == 1:
        filters["is_popular"] = True

    products = Product.objects.filter(**filters).order_by("-created_at")

    results = []
    for p in products:
        results.append(
            ProductOutSchema(
                id=p.id,
                title=p.title,
                description=p.description,
                price=p.price,
                created_at=p.created_at,
                images=[ProductImageOutSchema(url=img.image.url) for img in p.images.all()],
            )
        )

    return 200, results


@router.get(
    path="/banners/",
    description="Banners List",
    response={200: List[BannerOutSchema]},
    tags=["Banners"],
)
def list_banners(request: HttpRequest) -> List[BannerOutSchema]:
    data = Banner.objects.all().order_by("created_at")

    return 200, data


@router.post("/orders/", description="Order Create", tags=["Orders"])
def create_order(request, payload: OrderInSchema):
    order = Order.objects.create(
        name=payload.name,
        phone=payload.phone,
        total_price=payload.total_price,
    )
    order.products.set([p.id for p in payload.products])
    order.save()

    asyncio.run(send_order_notification(order=payload))

    return {"message": "ok"}
