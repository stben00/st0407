from ninja import Router

from onlinestore_backend.apps.products.api.public import router as products_router

public_router = Router(tags=["public"])
public_router.add_router("products/", products_router)

