from ninja import Router

from birgo_backend.apps.adverts.api.views import adverts_private_router as adverts_router
from birgo_backend.apps.payments.api.views import payments_private_router as payments_router
from birgo_backend.apps.users.api.views import users_private_router as users_router

private_router = Router(tags=["private"])
private_router.add_router("user/", users_router)
private_router.add_router("adverts/", adverts_router, auth=None)
private_router.add_router("payments/", payments_router, auth=None)
