#!/bin/sh
poetry run python /backend/onlinestore_backend/manage.py collectstatic --no-input

poetry run gunicorn onlinestore_backend.core.wsgi:application \
  --bind $GUNICORN_HOST:$GUNICORN_PORT \
  --workers $GUNICORN_SERVER_WORKERS \
  --log-level debug \
  --timeout $GUNICORN_SERVER_TIMEOUT \
  --max-requests $GUNICORN_MAX_REQUESTS \
  --max-requests-jitter $GUNICORN_MAX_REQUESTS_JITTER